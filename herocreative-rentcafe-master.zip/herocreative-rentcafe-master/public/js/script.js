jQuery(document).ready(function($) {
  $('.herocreative-rentcafe-tabs').tabs();
});